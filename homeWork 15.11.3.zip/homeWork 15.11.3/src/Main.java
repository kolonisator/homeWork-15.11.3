public class Main {
    public static void main(String[] args) {
        boolean isYearFinished = true;
        boolean isGoodWeather = true;
        boolean isBadWeather = false;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = false;
        boolean goingOnHike = (isYearFinished && (isGoodWeather || (isBadWeather && hasBoughtRaincoats)) && (isJimFree^hasKateComeBack ));
        System.out.println(goingOnHike);
    }
}